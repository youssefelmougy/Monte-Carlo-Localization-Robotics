# mock rclpy

def init(*args, **kwargs):
    pass


def spin(*args, **kwargs):
    pass


def shutdown(*args, **kwargs):
    pass